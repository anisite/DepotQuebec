# xbmc-kodi-TV5-Quebec-Canada

Plug-in Kodi pour visionner le contenu de tv5.ca - DEVELOPPEMENT

POUR TÉLÉCHARGER UN .ZIP POUR VOTRE KODI C'EST ICI: -> https://github.com/ssenechal67/plugin.video.tv5.quebec-canada

