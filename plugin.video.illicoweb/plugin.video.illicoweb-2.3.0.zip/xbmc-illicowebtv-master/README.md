xbmc-illicowebtv
=================

XMBC Addon for Canadian Videotron Illico Web Tv Service

** ATTENTION **
---------------
Ce Addon requiert un abonnement � la t�l�vision Illico de Vid�otron.  Vous devez d�j� pouvoir visionner des cha�nes sur illico.tv afin d'utiliser ce Addon.

Le nouveau syst�me d'Illico implant� le 7 novembre 2013 peut ne pas �tre parfaitement support� par votre version de XBMC.  Si l'�coute gel au bout de quelques secondes, vous devez mettre � jour LIBRTMP.DLL en suivant les instructions officielle de XBMC.org:
http://wiki.xbmc.org/index.php?title=HOW-TO:Update_librtmp

Il n'est pas possible de faire Pause sans causer un gel sur les transmissions IllicoWeb sur demande avec la version actuelle de XBMC.


Comment utiliser les Favoris IllicoWeb?
---------------------------------------
Les Favoris IllicoTV se trouvent, quand vous en aurez d�finis, en haut de la liste des cha�nes.  Pour ajouter une cha�ne, une �mission ou une saison � vos favoris, il vous suffit de faire click-droit ou appuyer la touche 'c' pour obtenir le menu sur l'item � d�finir comme favori et faire 'Ajouter � Mes Favoris'.

Il est possible d'ajouter '-- Mes Favoris IllicoTV --' � vos Favoris de XBMC en acc�dant le menu de celui-ci.  De cette fa�on vous pourrez regrouper vos �missions ou cha�nes pr�f�r�es en un endroit et les acc�der rapidement par les favoris de XBMC.


